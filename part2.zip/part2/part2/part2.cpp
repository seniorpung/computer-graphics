#include <gl/glut.h>
#include <stdio.h>
#include <iostream>
#include <vector>


void drawRectangle(float x, float y, float width, float height) {
	glBegin(GL_POLYGON);
	glVertex2f(x, y);
	glVertex2f(x + width, y);
	glVertex2f(x + width, y + height);
	glVertex2f(x, y + height);
	glEnd();
}

void uaeFlag() {
	int windowWidth = glutGet(GLUT_WINDOW_WIDTH);
	int windowHeight = glutGet(GLUT_WINDOW_HEIGHT);

	//this is for defining the flag size 
	float flagWidth = windowWidth * 0.7;
	float flagHeight = windowHeight * 0.7;

	// to showing the flag on the center or the window 
	float flagX = (windowWidth - flagWidth) / 2.0;
	float flagY = (windowHeight - flagHeight) / 2.0;

	// Set up viewport and projection matrix for the middle of the window
	glViewport(flagX, flagY, flagWidth, flagHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-1.5, 1.5, -1.5, 1.5);


	// because the by default background color is black so we change it white  
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);

	glColor3f(0.0, 1.0, 0.0);
	drawRectangle(-1.0, 0.5, 2.0, 0.25);
	glColor3f(1.0, 1.0, 1.0);
	drawRectangle(-1.0, 0.25, 2.0, 0.25);
	glColor3f(0.0, 0.0, 0.0);
	drawRectangle(-1.0, 0.0, 2.0, 0.25);
	glColor3f(1.0, 0.0, 0.0);
	drawRectangle(0.75, 0.0, 0.25, 0.75);
	glFlush();
}

struct Point {
	float x, y;
};

void drawPlus(std::vector<Point> controlPoints) {
	for (float t = 0.0; t <= 1.0; t += 0.001) {
		float x = pow(1.0 - t, 3) * controlPoints[0].x + 3 * pow(1.0 - t, 2) * t * controlPoints[1].x + 3 * (1.0 - t) * pow(t, 2) * controlPoints[2].x + pow(t, 3) * controlPoints[3].x;
		float y = pow(1.0 - t, 3) * controlPoints[0].y + 3 * pow(1.0 - t, 2) * t * controlPoints[1].y + 3 * (1.0 - t) * pow(t, 2) * controlPoints[2].y + pow(t, 3) * controlPoints[3].y;
		glVertex2f(x, y);
	}
}

void drawMinus(std::vector<Point> controlPoints) {
	for (float t = 1.0; t >= 0.0; t -= 0.001) {
		float x = pow(1.0 - t, 3) * controlPoints[0].x + 3 * pow(1.0 - t, 2) * t * controlPoints[1].x + 3 * (1.0 - t) * pow(t, 2) * controlPoints[2].x + pow(t, 3) * controlPoints[3].x;
		float y = pow(1.0 - t, 3) * controlPoints[0].y + 3 * pow(1.0 - t, 2) * t * controlPoints[1].y + 3 * (1.0 - t) * pow(t, 2) * controlPoints[2].y + pow(t, 3) * controlPoints[3].y;
		glVertex2f(x, y);
	}
}


void drawBezierCurve4(std::vector<Point> controlPoints1, std::vector<Point> controlPoints2, std::vector<Point> controlPoints3, std::vector<Point> controlPoints4) {
	glBegin(GL_POLYGON);
	drawMinus(controlPoints1);
	drawPlus(controlPoints2);
	drawPlus(controlPoints3);
	drawMinus(controlPoints4);
	glEnd();
}

void drawBezierCurve6(std::vector<Point> controlPoints1, std::vector<Point> controlPoints2, std::vector<Point> controlPoints3, std::vector<Point> controlPoints4, std::vector<Point> controlPoints5, std::vector<Point> controlPoints6) {
	glBegin(GL_POLYGON);
	drawPlus(controlPoints1);
	drawPlus(controlPoints2);
	drawMinus(controlPoints3);
	drawMinus(controlPoints4);
	drawMinus(controlPoints5);
	drawMinus(controlPoints6);
	glEnd();
}

void useFlagCurves() {

	std::vector<Point> ControlPoints1;
	ControlPoints1.push_back({ -0.93, 0.3 });
	ControlPoints1.push_back({ -0.9, 0.2 });
	ControlPoints1.push_back({ -0.9, 0.1 });
	ControlPoints1.push_back({ -0.9, 0.0 });
	std::vector<Point> ControlPoints2;
	ControlPoints2.push_back({ -0.9, 0.0 });
	ControlPoints2.push_back({ -0.895, -0.1 });
	ControlPoints2.push_back({ -0.895, -0.2 });
	ControlPoints2.push_back({ -0.9, -0.3 });
	std::vector<Point> ControlPoints3;
	ControlPoints3.push_back({ -0.9, -0.3 });
	ControlPoints3.push_back({ -0.9, -0.4 });
	ControlPoints3.push_back({ -0.9, -0.5 });
	ControlPoints3.push_back({ -0.93, -0.6 });
	std::vector<Point> ControlPoints4;
	ControlPoints4.push_back({ -0.93, 0.3 });
	ControlPoints4.push_back({ -0.6, 0.1 });
	ControlPoints4.push_back({ -0.3, 0.4 });
	ControlPoints4.push_back({ 0.0, 0.3 });
	std::vector<Point> ControlPoints5;
	ControlPoints5.push_back({ -0.9, 0.0 });
	ControlPoints5.push_back({ -0.57, -0.2 });
	ControlPoints5.push_back({ -0.27, 0.1 });
	ControlPoints5.push_back({ 0.03, 0.0 });
	std::vector<Point> ControlPoints6;
	ControlPoints6.push_back({ -0.9, -0.3 });
	ControlPoints6.push_back({ -0.57, -0.5 });
	ControlPoints6.push_back({ -0.27, -0.2 });
	ControlPoints6.push_back({ 0.03, -0.3 });
	std::vector<Point> ControlPoints7;
	ControlPoints7.push_back({ -0.93, -0.6 });
	ControlPoints7.push_back({ -0.6, -0.8 });
	ControlPoints7.push_back({ -0.3, -0.5 });
	ControlPoints7.push_back({ 0.0, -0.6 });
	std::vector<Point> ControlPoints8;
	ControlPoints8.push_back({ 0.0, 0.3 });
	ControlPoints8.push_back({ 0.03, 0.2 });
	ControlPoints8.push_back({ 0.03, 0.1 });
	ControlPoints8.push_back({ 0.03, 0.0 });
	std::vector<Point> ControlPoints9;
	ControlPoints9.push_back({ 0.03, 0.0 });
	ControlPoints9.push_back({ 0.035, -0.1 });
	ControlPoints9.push_back({ 0.035, -0.2 });
	ControlPoints9.push_back({ 0.03, -0.3 });
	std::vector<Point> ControlPoints10;
	ControlPoints10.push_back({ 0.03, -0.3 });
	ControlPoints10.push_back({ 0.03, -0.4 });
	ControlPoints10.push_back({ 0.03, -0.5 });
	ControlPoints10.push_back({ 0.0, -0.6 });
	std::vector<Point> ControlPoints11;
	ControlPoints11.push_back({ -1.13, 0.3 });
	ControlPoints11.push_back({ -1.1, 0.0 });
	ControlPoints11.push_back({ -1.1, -0.3 });
	ControlPoints11.push_back({ -1.13, -0.6 });
	std::vector<Point> ControlPoints12;
	ControlPoints12.push_back({ -1.13, 0.3 });
	ControlPoints12.push_back({ -1.07, 0.35 });
	ControlPoints12.push_back({ -0.99, 0.35 });
	ControlPoints12.push_back({ -0.93, 0.3 });
	std::vector<Point> ControlPoints13;
	ControlPoints13.push_back({ -1.13, -0.6 });
	ControlPoints13.push_back({ -1.07, -0.55 });
	ControlPoints13.push_back({ -0.99, -0.55 });
	ControlPoints13.push_back({ -0.93, -0.6 });

	int windowWidth = glutGet(GLUT_WINDOW_WIDTH);
	int windowHeight = glutGet(GLUT_WINDOW_HEIGHT);

	//this is for defining the flag size 
	float flagWidth = windowWidth * 0.7;
	float flagHeight = windowHeight * 0.7;

	// to showing the flag on the center or the window 
	float flagX = (windowWidth - flagWidth) / 2.0;
	float flagY = (windowHeight - flagHeight) / 2.0;

	// Set up viewport and projection matrix for the middle of the window
	glViewport(flagX, flagY, flagWidth, flagHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-1.5, 1.5, -1.5, 1.5);
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0, 1.0, 0.0);
	drawBezierCurve4(ControlPoints1, ControlPoints5, ControlPoints8, ControlPoints4);
	glColor3f(0.9, 0.9, 0.9);
	drawBezierCurve4(ControlPoints2, ControlPoints6, ControlPoints9, ControlPoints5);
	glColor3f(0.0, 0.0, 0.0);
	drawBezierCurve4(ControlPoints3, ControlPoints7, ControlPoints10, ControlPoints6);
	glColor3f(1.0, 0.0, 0.0);
	drawBezierCurve6(ControlPoints11, ControlPoints13, ControlPoints3, ControlPoints2, ControlPoints1, ControlPoints12);
	glFlush();

}

double XMat[4][4] = { { 100, 220, 240, 260},
					{105, 225, 235, 255 },
					{105, 225, 235, 255},
					{100, 220, 240, 260} };
double YMat[4][4] = { {200, 200, 240, 150},
					{230,250,250,230},
					{280,260,260,230},
					{300,320,320,200} };
double ZMat[4][4] = { {0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0} };

void myInit(void)
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);
	gluOrtho2D(0.0, 500.0, 0.0, 500.0);
}


void draw_pixel(int x, int y, float r, float g, float b) {
	glBegin(GL_POINTS);
	glColor3f(r, g, b);
	glVertex2i(x, y);
	glEnd();
}


void draw_curve() {
	
	double u, w;

	double x, y;
	double A[1][4], B[4][1];
	for (u = -0.5; u <= 0.5; u = u + 0.0005) {
		for (w = -0.01; w <= 0.0; w = w + 0.0005) {
			A[0][0] = (1 - u) * (1 - u) * (1 - u);
			A[0][1] = 3 * u * (1 - u) * (1 - u);
			A[0][2] = 3 * u * u * (1 - u);
			A[0][3] = u * u * u;

			B[0][0] = (1 - w) * (1 - w) * (1 - w);
			B[1][0] = 3 * w * (1 - w) * (1 - w);
			B[2][0] = 3 * w * w * (1 - w);
			B[3][0] = 3 * w * w * w;

			x = (A[0][0] * XMat[0][0] + A[0][1] * XMat[1][0] + A[0][2] * XMat[2][0] + A[0][3] * XMat[3][0]) * B[0][0] + (A[0][0] * XMat[0][1] + A[0][1] * XMat[1][1] + A[0][2] * XMat[2][1] + A[0][3] * XMat[3][1]) * B[1][0] + (A[0][0] * XMat[0][2] + A[0][1] * XMat[1][2] + A[0][2] * XMat[2][2] + A[0][3] * XMat[3][2]) * B[2][0] + (A[0][0] * XMat[0][3] + A[0][1] * XMat[1][3] + A[0][2] * XMat[2][3] + A[0][3] * XMat[3][3]) * B[3][0];
			y = (A[0][0] * YMat[0][0] + A[0][1] * YMat[1][0] + A[0][2] * YMat[2][0] + A[0][3] * YMat[3][0]) * B[0][0] + (A[0][0] * YMat[0][1] + A[0][1] * YMat[1][1] + A[0][2] * YMat[2][1] + A[0][3] * YMat[3][1]) * B[1][0] + (A[0][0] * YMat[0][2] + A[0][1] * YMat[1][2] + A[0][2] * YMat[2][2] + A[0][3] * YMat[3][2]) * B[2][0] + (A[0][0] * YMat[0][3] + A[0][1] * YMat[1][3] + A[0][2] * YMat[2][3] + A[0][3] * YMat[3][3]) * B[3][0];
			draw_pixel(x, y, 0.5, 0.5, 0.0);
		}
	}
	for (u = 0; u <= 0.5; u = u + 0.0005)
	{
		for (w = 0; w <= 0.5; w = w + 0.0005)
		{
			A[0][0] = (1 - u) * (1 - u) * (1 - u);
			A[0][1] = 3 * u * (1 - u) * (1 - u);
			A[0][2] = 3 * u * u * (1 - u);
			A[0][3] = u * u * u;

			B[0][0] = (1 - w) * (1 - w) * (1 - w);
			B[1][0] = 3 * w * (1 - w) * (1 - w);
			B[2][0] = 3 * w * w * (1 - w);
			B[3][0] = 3 * w * w * w;

			x = (A[0][0] * XMat[0][0] + A[0][1] * XMat[1][0] + A[0][2] * XMat[2][0] + A[0][3] * XMat[3][0]) * B[0][0] + (A[0][0] * XMat[0][1] + A[0][1] * XMat[1][1] + A[0][2] * XMat[2][1] + A[0][3] * XMat[3][1]) * B[1][0] + (A[0][0] * XMat[0][2] + A[0][1] * XMat[1][2] + A[0][2] * XMat[2][2] + A[0][3] * XMat[3][2]) * B[2][0] + (A[0][0] * XMat[0][3] + A[0][1] * XMat[1][3] + A[0][2] * XMat[2][3] + A[0][3] * XMat[3][3]) * B[3][0];
			y = (A[0][0] * YMat[0][0] + A[0][1] * YMat[1][0] + A[0][2] * YMat[2][0] + A[0][3] * YMat[3][0]) * B[0][0] + (A[0][0] * YMat[0][1] + A[0][1] * YMat[1][1] + A[0][2] * YMat[2][1] + A[0][3] * YMat[3][1]) * B[1][0] + (A[0][0] * YMat[0][2] + A[0][1] * YMat[1][2] + A[0][2] * YMat[2][2] + A[0][3] * YMat[3][2]) * B[2][0] + (A[0][0] * YMat[0][3] + A[0][1] * YMat[1][3] + A[0][2] * YMat[2][3] + A[0][3] * YMat[3][3]) * B[3][0];
			if (w > 0.1) {
				if (u < 0.17)
					draw_pixel(x, y, 0, 0, 0);
				else if (u >= 0.17 && u < 0.34)
					draw_pixel(x, y, 0.9, 0.9, 0.9);
				else
					draw_pixel(x, y, 0, 1, 0);
			} else draw_pixel(x, y, 1, 0, 0);
			
		}
	}




}

void useFlagSurfaces() {
	glClear(GL_COLOR_BUFFER_BIT);
	draw_curve();
	glFlush();
}

int main(int argc, char** argv) {
	int type; 
	std::cin >> type;
	if (type == 1 || type == 2) {
		glutInit(&argc, argv);
		glutCreateWindow("UAE Flag");
		glutInitWindowSize(800, 600);
		glutInitWindowPosition(100, 100);
		if (type == 1) glutDisplayFunc(uaeFlag);
		else glutDisplayFunc(useFlagCurves);
		glutMainLoop();
	}
	else {
		glutInit(&argc, argv);
		glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
		glutInitWindowSize(500, 500);
		glutInitWindowPosition(0, 0);
		glutCreateWindow("Cubic Bezier Curve");
		myInit();
		glutDisplayFunc(useFlagSurfaces);
		glutMainLoop();
	}


	return 0;
}